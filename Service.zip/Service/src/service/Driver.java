/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.Scanner;

/**
 *
 * @author Astri Neva
 */
public class Driver {
    public static void main(String[] args) {
        System.out.println("1. Starter Package");
        System.out.println("2. Pro Package");
        System.out.println("3. Enterprise Package");
        System.out.print("Masukkan pilihan package: ");
        Scanner i=new Scanner(System.in);
        int pilihan1=i.nextInt();
        
        System.out.print("1. Jumlah Add 1 user: ");
        double jumlah1= i.nextInt();
        System.out.print("2. Jumlah 100 API call: ");        
        double jumlah2= i.nextInt();
        
        Packages myPackage=new Packages();
        
        double harga=0;
        if(pilihan1==1)
        {
            harga=myPackage.totalHarga("Starter Package", jumlah1, jumlah2);
        }
        else if(pilihan1==2)
        {
            harga=myPackage.totalHarga("Pro Package", jumlah1, jumlah2);
        }
        else if(pilihan1==3)
        {
            harga=myPackage.totalHarga("Enterpise Package", jumlah1, jumlah2);
        }
        System.out.println(harga);
    }
}