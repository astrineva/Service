/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author Astri Neva
 */
public class Packages {
   
   String name;
   double price;
   String desc;
   
   public Packages() {
   }

   public Packages(String name, double price, String desc) {
        this.name = name;
        this.price = price;
        this.desc = desc;
   }
   
   double total=0;
   public double totalHarga(String name, double jumlah1, double jumlah2)
   {   
        if(name.equalsIgnoreCase("Starter Package"))
       {
            price=150; 
            desc="1 User";
            total+=price+10*jumlah1+5*jumlah2;
       }
       else if(name.equalsIgnoreCase("Pro Package"))
       {
            price=200; 
            desc="3 User";
            total+=price+10*jumlah1+5*jumlah2;
       }
       else if(name.equalsIgnoreCase("Enterprise Package"))
       {
            price=250; 
            desc="5 User";
            total+=price+10*jumlah1+5*jumlah2;
       }
       return total;
   }
    
}
